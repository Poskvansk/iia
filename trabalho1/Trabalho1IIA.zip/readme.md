# Trabalho 1 de IIA
## Alunos
Gabriel Oliveira do Espirito Santo - 18/0041835
Luis Filipe Siqueira Ribeiro - 18/0053906

## Como compilar
```python3 main.py```

### Alterar o metodo de reproducao
alterar a linha 61 do arquivo main.py de:
```new_gen = crossover(population)```
para: 
```new_gen = crossover2(population)```